package com.example.theresavassellapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText nameText;
    private TextView textGreeting;
    private Button SayHello;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nameText = findViewById(R.id.nameText);
        textGreeting = findViewById(R.id.textGreeting);
        SayHello = findViewById(R.id.buttonSayHello);
        SayHello.setEnabled(false);

        // attach text change listener for nameText
        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) { }

            @Override
            public void afterTextChanged(Editable s) {
                // check nameText contains a string or not
                // if not contain
                // enable sayHello button
                SayHello.setEnabled(!s.toString().equals("")); // disable sayHello button
            }
        });
    }


    @SuppressLint("SetTextI18n")
    public void SayHello(View v){
        String name = nameText.getText().toString();
        if (name.equals("")){
            textGreeting.setText("You must enter a name"); // update text greeting
        }else {
            textGreeting.setText("Hello, "+name+"!"); // update text greeting
        }
    }
}